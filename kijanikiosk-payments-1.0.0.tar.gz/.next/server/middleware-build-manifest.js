globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/oL_qPGo8-XLG330U_2mf8/_buildManifest.js",
    "static/oL_qPGo8-XLG330U_2mf8/_ssgManifest.js",
    "static/oL_qPGo8-XLG330U_2mf8/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3ll07n217cgxf.js",
    "static/chunks/0cbr67yte101v.js",
    "static/chunks/0iec5q4ack_04.js",
    "static/chunks/turbopack-0nqnc73oa2lgs.js"
  ]
};
